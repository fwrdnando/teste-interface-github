from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

def test_busca_github(browser):
    browser.get("https://github.com")
    search_input = browser.find_element(By.NAME, "q")
    search_input.send_keys("selenium")
    search_input.send_keys(Keys.RETURN)
    time.sleep(2)
    results = browser.find_elements(By.CLASS_NAME, "repo-list-item")
    assert len(results) > 0, "Nenhum repositório encontrado para 'selenium'"
