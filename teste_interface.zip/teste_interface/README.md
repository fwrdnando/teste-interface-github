# Teste Automatizado com Selenium + Pytest

Este projeto realiza testes automatizados no site do GitHub usando Selenium WebDriver e Pytest.

## 🔍 O que é testado?

- Abertura da homepage do GitHub
- Realização de uma busca por "selenium"
- Verificação de que resultados são retornados

## 🚀 Como rodar

### 1. Instale os requisitos
```bash
pip install -r requirements.txt
```

### 2. Execute o teste
```bash
pytest tests/
```

> O teste será executado em modo headless (sem abrir o navegador visivelmente).

## 🛠 Tecnologias
- Python
- Selenium
- Pytest
- Webdriver Manager

## 📂 Estrutura
- `tests/`: contém os testes
- `conftest.py`: configura o WebDriver
- `requirements.txt`: dependências do projeto
